import sys
sys.argv = [ "/homes/grads/dek61/SNIPER/sniper/scripts/stop-by-icount.py", "10000000000" ]
execfile("/homes/grads/dek61/SNIPER/sniper/scripts/stop-by-icount.py")
